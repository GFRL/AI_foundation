#include<iostream>
#include<random>
#include<cstdio>
#include<algorithm>
#include<string>
#include<cmath>
#include<cstring>
#include<map>
#include<vector>
#include<queue>
#include<ctime>
#include<string.h>
#include "jsoncpp/json.h"
#define MTCSXS 0.1
#define N 11
using namespace std;

class RandomVariables {
private:

	// �̶��������
	RandomVariables() = default;

	// �ǹ̶��������
	// RandomVariables() : random_engine(time(nullptr)) {}

	~RandomVariables() = default;

	std::default_random_engine random_engine;
	std::uniform_real_distribution<double> uniform_dist;
	std::uniform_int_distribution<int> uniform_int_dist;

	static RandomVariables rv;

public:

	// ���ȷֲ���������
	static int uniform_int() {
		return rv.uniform_int_dist(rv.random_engine);
	}

	// [0,1)���ȷֲ���ʵ��
	static double uniform_real() {
		return rv.uniform_dist(rv.random_engine);
	}

	// �ȸ��ʷֲ���{0,1,2,n-1}����
	static std::vector<int> uniform_permutation(int n) {
		std::vector<int> permutation(n);
		for (int i = 0; i < n; ++i) {
			permutation[i] = i;
		}

		for (int i = 0, j; i < n; ++i) {
			j = uniform_int() % (n - i) + i;
			std::swap(permutation[i], permutation[j]);
		}

		return permutation;
	}
};

RandomVariables RandomVariables::rv;

//global values statetion
char symbol[3] = { 'X','?','Y' };

int GRID[N+2][N+2];//-1��,1��;
int xx[6] = { 0,1,1,0,-1,-1 }, yy[6] = { -1,-1,0,1,1,0};
int vis[N+2][N+2];//�ֱ���������DFS
int bs;
int now_camp;
clock_t t0;
inline int Min(int a, int b) { return a < b ? a : b; }
int Tnode0_expand_times;

double evaluation[14] = { 1e9,100000,20000,5000,1111,370,123,41,13,4,1,0.033,0.011,0.003 };

struct Node {
	int x, y, value;
	Node(int x, int y, int value) :x(x), y(y), value(value) {};
};
struct cmp {
	bool operator()(Node A, Node B) { return A.value > B.value; }
};
inline int pos(int X, int Y) { return X * N + Y - N - 1; }
struct Treenode {
	int x, y, camp, tree_father;//�����ո�������������,ע��camp���״̬��Ҫ�������camp�෴;
	vector<int>choice;//�������ӽڵ���
	vector<int>choice_position;//�������ж������ڵ�λ��
	vector<int>Father; int expand_times;
	//vector<vector<int>>Q;
	vector<int>Value0[2], Value1[2];//0�����Ͻ���,1������Զ��;1�Ǻ�,0����
	double GZ[3];//0�Ǻ�,2����,GZ[2]*campԽ��˵�����ڶ�Ҫ�����˵���Խ�ã�����1000000�����ж���ʤ;
	int choice_num, choice_all_num;
	//map<int, int>paths;
	double UTB;
	double expand_all_values;
	//bool empty_node_surround[6];//����ĳ����Χ����,����˫������
	//find father,return father;
	int GetFather(int node_NO) {
		if (Father[node_NO] == node_NO)return node_NO;
		else return Father[node_NO] = GetFather(Father[node_NO]);
	}
	//join two nodes,return father;
	inline int Join(int node1, int node2, int camp = 0) {
		int s = GetFather(node1), t = GetFather(node2);
		return Father[s] = t;
	}
	//find the distance;3 types:up,down,both;
	inline int Getdistance(int node, int camp) { return Value0[camp][node] + Value1[camp][node]; }
	//return GZ1;
	double Path_update() {
		//Father_update
		for (int i = 0; i < 6; i++) {
			int X0 = x + xx[i], Y0 = y + yy[i];
			if (GRID[X0][Y0] == camp)Join(pos(X0,Y0), pos(x,y));
		}
		for (int i = 0; i < N * N; i++)GetFather(i);
		deque<Node>Q;
		Node tmp(0, 0, 0);

		//Value0[0];�����Ͻ���
		{
			memset(vis, 0, sizeof(vis));
			for (int i = 1; i <=N; i++) { if (GRID[i][1]==1)Q.push_front(Node(i, 1, 0)),Value0[0][pos(i,1)] = 0; else if (!GRID[i][1])Q.push_back(Node(i, 1, 1)), Value0[0][pos(i,1)] = 1; }
			while (!Q.empty()) {
				Node tmp = Q.front(); Q.pop_front(); if (vis[tmp.x][tmp.y])continue;
				else {
					vis[tmp.x][tmp.y] = true;
					for (int i = 0; i < 6; i++) {
						int X0 = tmp.x + xx[i], Y0 = tmp.y + yy[i];
						if (GRID[X0][Y0]!=-100&&!vis[X0][Y0]) {
							if (!GRID[X0][Y0] && tmp.value < Value0[0][pos(X0,Y0)]) {
								Value0[0][pos(X0,Y0)] = tmp.value + 1;
								Q.push_back(Node(X0, Y0, tmp.value + 1));
							}
							else if (GRID[X0][Y0] > 0 && tmp.value <= Value0[0][pos(X0,Y0)]) {
								Value0[0][pos(X0,Y0)] = tmp.value;
								Q.push_front(Node(X0, Y0, tmp.value)); 
							}
						}
					}
				}
			}
		}
		//Value0[1];�췽�Ͻ���
		{
			memset(vis, 0, sizeof(vis));
			for (int i = 1; i <= N; i++) { if (GRID[1][i] == -1)Q.push_front(Node(1, i, 0)),Value0[1][pos(1,i)] = 0; else if (!GRID[1][i])Q.push_back(Node(1, i, 1)), Value0[1][pos(1,i)] = 1; }
			while (!Q.empty()) {
				Node tmp = Q.front(); Q.pop_front(); if (vis[tmp.x][tmp.y])continue;
				else {
					vis[tmp.x][tmp.y] = true;
					for (int i = 0; i < 6; i++) {
						int X0 = tmp.x + xx[i], Y0 = tmp.y + yy[i];
						if (GRID[X0][Y0]!=-100 && !vis[X0][Y0]) {
							if (!GRID[X0][Y0] && tmp.value < Value0[1][pos(X0,Y0)]) {
								Value0[1][pos(X0,Y0)] = tmp.value + 1;
								Q.push_back(Node(X0, Y0, tmp.value + 1));
							}
							else if (GRID[X0][Y0] < 0 && tmp.value <= Value0[1][pos(X0,Y0)]) {
								Value0[1][pos(X0,Y0)] = tmp.value;
								Q.push_front(Node(X0, Y0, tmp.value)); 
							}
						}
					}
				}
			}
		}

		//Value1[0];������Զ��
		{
			memset(vis, 0, sizeof(vis));
			for (int i = 1; i <= N; i++) { if (GRID[i][N]==1)Q.push_front(Node(i, N, 0)), Value1[0][pos(i,N)] = 0; else if (!GRID[i][N])Q.push_back(Node(i, N, 1)), Value1[0][pos(i,N)] = 1; }
			while (!Q.empty()) {
				Node tmp = Q.front(); Q.pop_front(); if (vis[tmp.x][tmp.y])continue;
				else {
					vis[tmp.x][tmp.y] = true;
					for (int i = 0; i < 6; i++) {
						int X0 = tmp.x + xx[i], Y0 = tmp.y + yy[i];
						if (GRID[X0][Y0]!=-100 && !vis[X0][Y0]) {
							if (!GRID[X0][Y0] && tmp.value < Value1[0][pos(X0,Y0)]) {
								Value1[0][pos(X0,Y0)] = tmp.value + 1;
								Q.push_back(Node(X0, Y0, tmp.value + 1));
							}
							else if (GRID[X0][Y0] > 0 && tmp.value <= Value1[0][pos(X0,Y0)]) {
								Value1[0][pos(X0,Y0)] = tmp.value;
								Q.push_front(Node(X0, Y0, tmp.value)); 
							}
						}
					}
				}
			}
		}

		//Value1[1];�췽��Զ��
		{
			memset(vis, 0, sizeof(vis));
			for (int i = 1; i <= N; i++) { if (GRID[N][i] == -1)Q.push_front(Node(N, i, 0)), Value1[1][pos(N, i)] = 0; else if (!GRID[N][i])Q.push_back(Node(N, i, 1)), Value1[1][pos(N, i)] = 1; }
			while (!Q.empty()) {
				Node tmp = Q.front(); Q.pop_front(); if (vis[tmp.x][tmp.y])continue;
				else {
					vis[tmp.x][tmp.y] = true;
					for (int i = 0; i < 6; i++) {
						int X0 = tmp.x + xx[i], Y0 = tmp.y + yy[i];
						if (GRID[X0][Y0]!=-100&& !vis[X0][Y0]) {
							if (!GRID[X0][Y0]&& tmp.value < Value1[1][pos(X0,Y0)]) {
								Value1[1][pos(X0,Y0)] = tmp.value + 1;
								Q.push_back(Node(X0, Y0, tmp.value + 1));
							}
							else if (GRID[X0][Y0] == -1 && tmp.value <= Value1[1][pos(X0,Y0)]) {
								Value1[1][pos(X0,Y0)] = tmp.value;
								Q.push_front(Node(X0, Y0, tmp.value));
							}
						}
					}
				}
			}
		}

		//GZ����
		memset(vis, 0, sizeof(vis));
		for (int i = 0; i < N * N; i++) {
			int X0 = (Father[i] / N), Y0 =(Father[i] - N * X0);
			X0++, Y0++;
			if (!vis[X0][Y0]&&(GRID[X0][Y0]==1||GRID[X0][Y0]==-1)){
				int s = Getdistance(Father[i], (1 - GRID[X0][Y0]) / 2);
				vis[X0][Y0] = true;
				if (s < 14)
					GZ[GRID[X0][Y0] + 1] += evaluation[s];
			}
		}
		GZ[1] = (GZ[0] - GZ[2]) * camp; return GZ[1];
	}
	double UTB_update() {
		return UTB = expand_all_values / expand_times + MTCSXS*bs*pow(N*N* expand_times/Tnode0_expand_times ,2);
	}
}Tnode[20001];
int Tnode_cnt = 0;
vector<int>Value_standrad;
Treenode Root;

void Reset() {
	fill(Tnode, Tnode + 20000, Treenode{});
	Tnode_cnt = 0;
}
//����ʱ�Զ��ı�GRID;�˳�ʱ�ḴԭGRID special����ָ�����ӱ��;
int Treenode_bulit(int position, int camp, int father, int special = -1) {
	if (special >= 0)Tnode[father].choice_num = special;
	int x =(position / N), y =(position - N * x);
	x++; y++;
	Tnode[father].choice.push_back(++Tnode_cnt); Tnode[father].choice_num++;
	Tnode[Tnode_cnt].x = x; Tnode[Tnode_cnt].y = y; Tnode[Tnode_cnt].camp = camp; Tnode[Tnode_cnt].tree_father = father;
	Tnode[Tnode_cnt].Father = Tnode[father].Father;
	Tnode[Tnode_cnt].GZ[0] = Tnode[Tnode_cnt].GZ[2] = 0;
	Tnode[Tnode_cnt].Value0[0] = Value_standrad; Tnode[Tnode_cnt].Value0[1] = Value_standrad; Tnode[Tnode_cnt].Value1[0] = Value_standrad; Tnode[Tnode_cnt].Value1[1] = Value_standrad;
	GRID[x][y] = camp;
	double tmppp = Tnode[Tnode_cnt].Path_update();
	//�˴���ʱȥ���ذ�����
	Tnode[Tnode_cnt].choice_num = 0; Tnode[Tnode_cnt].choice_all_num = Tnode[father].choice_all_num - 1;
	for (int i = 0; i < Tnode[father].choice_num - 1; i++) {
		Tnode[Tnode_cnt].choice_position.push_back(Tnode[father].choice_position[i]);
	}
	for (int i = Tnode[father].choice_num; i < Tnode[father].choice_all_num; i++)Tnode[Tnode_cnt].choice_position.push_back(Tnode[father].choice_position[i]);
	//for (int i = 0; i <= Tnode[Tnode_cnt].choice_all_num; i++)
		//if (Tnode[father].choice_position[i] != position)Tnode[Tnode_cnt].choice_position.push_back(Tnode[father].choice_position[i]);

	GRID[x][y] = 0;
	return Tnode_cnt;
}
int Treenode_expand(int father) {
	if (Tnode[father].choice_num != Tnode[father].choice_all_num) {
		if(father!=0)
		GRID[Tnode[father].x][Tnode[father].y] = Tnode[father].camp;
		return Treenode_bulit(Tnode[father].choice_position[Tnode[father].choice_num], -Tnode[father].camp, father);
	}
	else {
		if (!Tnode[father].choice_all_num)return father;
		vector<int>BESTSON; double Bestvalue = -1e11;
		for (int i = 0; i < Tnode[father].choice_all_num; i++) {
			double tmp = -Tnode[Tnode[father].choice[i]].UTB_update();
			if (tmp > Bestvalue) { BESTSON.clear(); BESTSON.push_back(i); Bestvalue = tmp; }
			else if (tmp == Bestvalue) { BESTSON.push_back(i); }
		}
		GRID[Tnode[father].x][Tnode[father].y] = Tnode[father].camp;
		int s = Treenode_expand(Tnode[father].choice[BESTSON[RandomVariables::uniform_int() % BESTSON.size()]]);
		return s;
	}
}
void value_update(int now, double value) {
	Tnode[now].expand_times++; Tnode[now].expand_all_values += value;
	GRID[Tnode[now].x][Tnode[now].y] = 0;
	while (Tnode[now].tree_father != 0) {
		value *= -1; now = Tnode[now].tree_father; if (value < -10000000)value = -500000;
		Tnode[now].expand_times++; Tnode[now].expand_all_values += value;
		GRID[Tnode[now].x][Tnode[now].y] = 0;
	}
}
int MTCS(int camp) {
	t0 = clock();
	Reset();
	Tnode[0] = Root; Tnode[0].choice.clear(); Tnode[0].choice_num = 0; Tnode[0].expand_times = 1; Tnode[0].expand_all_values = 0;
	Tnode[0].tree_father = 0; Tnode0_expand_times = 1;
	//if(Tnode[0].GZ[1]>100000)
	while (clock() - t0 < 970 || Tnode0_expand_times < 600) {
		int m = Treenode_expand(0); value_update(m, Tnode[m].GZ[1]); Tnode[0].expand_times++; Tnode0_expand_times = Tnode[0].expand_times;
	}
	vector<int>BESTSON; double Bestvalue = -1e11;
	for (int i = 0; i < Tnode[0].choice_all_num; i++) {
		double tmp = -Tnode[Tnode[0].choice[i]].expand_all_values/Tnode[Tnode[0].choice[i]].expand_times;
		if (tmp > Bestvalue) { BESTSON.clear(); BESTSON.push_back(i); Bestvalue = tmp; }
		else if (tmp == Bestvalue) { BESTSON.push_back(i); }
	}
	if (bs == 0)return N * 1 + 3;
	cout << Tnode[0].expand_times << endl;
	return Tnode[0].choice[BESTSON[RandomVariables::uniform_int() % BESTSON.size()]];
}

void init1() {
	for (int i = 0; i <= N + 1; i++)GRID[i][0] = GRID[0][i] = GRID[N + 1][i] = GRID[i][N + 1] = -100;
	for (int i = 0; i < N * N; i++)Value_standrad.push_back(1e9);
	Root.camp = 1; Root.x = -1; Root.y = -1; Root.tree_father = -1;
	Root.choice_all_num = N * N; Root.choice_num = 0;
	for (int i = 0; i < N * N; i++) {
		Root.Father.push_back(i); Root.choice_position.push_back(i);
	}
	Root.expand_times = 1; Root.expand_all_values = 0; Root.GZ[1] = 0; Root.tree_father = -1;
}
void init2() {
	for (int i = 0; i <= N + 1; i++)GRID[i][0] = GRID[0][i] = GRID[N + 1][i] = GRID[i][N + 1] = -100;
	GRID[2][3] = -1;
	for (int i = 0; i < N * N; i++)Value_standrad.push_back(1e9);
	Root.camp = -1; Root.x = 2; Root.y = 3; Root.tree_father = -1;
	Root.choice_all_num = N * N - 1; Root.choice_num = 0;
	for (int i = 0; i < N + 2; i++) {
		Root.Father.push_back(i); Root.choice_position.push_back(i);
	}
	Root.Father.push_back(N + 2);
	for (int i = N + 3; i < N * N; i++) {
		Root.Father.push_back(i); Root.choice_position.push_back(i);
	}
	Root.expand_times = 1; Root.expand_all_values = 0; Root.GZ[1] = 0; Root.tree_father = -1;
}
void Renew(int s, int X2, int Y2) {//�봫���ڲ�ʵ�ֵ�X��Y��Ҳ���Ǽ���1�ģ�
	int POS2 = pos(X2,Y2);
	int l = 0, r = Tnode[s].choice_all_num - 1;
	while (l != r) {
		int mid = (l + r) >> 1;
		if (Tnode[s].choice_position[mid] > POS2)r = mid - 1;
		else if (Tnode[s].choice_position[mid] < POS2)l = mid + 1;
		else l = r = mid;
	}
	if (l >= Tnode[s].choice_num)Root = Tnode[Treenode_bulit(POS2, Tnode[s].camp * -1, s,l)];
	else Root = Tnode[Tnode[s].choice[l]];
	GRID[X2][Y2] = Root.camp;
}

void output() {
	for (int i = 1; i <=N; i++) {
		for (int j = 1; j <=N-i+1; j++)cout << " ";
		for (int j = 1; j <= i; j++)cout << symbol[GRID[i-j+1][j] + 1] << ' ';
		cout << endl;
	}
	for (int i = 1; i <N; i++) {
		for (int j = 1; j <= i+1; j++)cout << " ";
		for (int j = 1; j <= N - i; j++) {
			cout << symbol[GRID[N-j+1][i+j] + 1] << ' ';
		}
		cout << endl;
	}
}

void JSON_output(int u, int v) {//�봫���ڲ�X��Y;
	Json::Value result;
	Json::Value action;
	action["x"] = u-1; action["y"] = v-1;
	result["response"] = action;

	Json::FastWriter writer;

	cout << writer.write(result) << endl;
	cout << "\n>>>BOTZONE_REQUEST_KEEP_RUNNING<<<" << endl;
}
int main() {
	bs = 0;
	string str;
	getline(std::cin, str);
	Json::Reader reader;
	Json::Value input;
	reader.parse(str, input);
	int X1, X2, Y1, Y2; int s;

	if (input["requests"][0].isMember("forced_x")) {
		t0 = clock();
		init1();
		s = MTCS(now_camp);
		X1 = Tnode[s].x, Y1 = Tnode[s].y;
		now_camp = -1;
		GRID[X1][Y1] = now_camp;
		//output();
		JSON_output(X1, Y1);
		bs = 1;
		now_camp = -1;
	}
	else {
		t0 = clock();
		init2();
		bs = 2;
		s = MTCS(now_camp);
		X1 = Tnode[s].x, Y1 = Tnode[s].y;
		now_camp = 1;
		GRID[X1][Y1] = now_camp;
		//output();
		JSON_output(X1, Y1);
		now_camp = 1;
	}
	while (1) {
		bs += 2;
		getline(std::cin, str);
		reader.parse(str, input);
		X2 = input["x"].asInt()+1;
		Y2 = input["y"].asInt()+1;
		GRID[X2][Y2] = -now_camp;
		Renew(s, X2, Y2);
		s = MTCS(now_camp);
		if (s == 0)break;
		cin >> s;
		X1 = Tnode[s].x, Y1 = Tnode[s].y;	
		GRID[X1][Y1] = now_camp;
		
		JSON_output(X1, Y1);
		output();
	}
	return 0;
}